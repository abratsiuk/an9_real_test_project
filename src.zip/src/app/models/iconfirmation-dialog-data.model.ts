export interface IConfirmationDialogData {
  title: string;
  message: string;
  confirmText: string;
  cancelText: string;
}
