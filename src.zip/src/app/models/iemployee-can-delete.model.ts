export interface IEmployeeCanDelete {
  canDelete: boolean;
  reason?: string;
}
