export interface IDepartment {
  id: number;
  departmentName: string;
}
