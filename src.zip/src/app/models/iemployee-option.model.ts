export interface IEmployeeOption {
  id: number;
  fullName: string;
}
